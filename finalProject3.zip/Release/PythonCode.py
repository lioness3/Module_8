import re
import string

groceryFile = open("GroceryList.txt","r") # read grocery inventory 
groceryItems = groceryFile.read().split() # read items  
uniqueItems = {} # empty dict 

for word in groceryItems:  # loop through list
    if not word in uniqueItems: # find items that havnt been listed yet 
        uniqueItems[word] = groceryItems.count(word) # count number of items
groceryFile.close() # close file
 
 # create a frequency report file
def createFrequencyFile():
    frequencyFile = open("frequency.dat", "w")
    for item, count in uniqueItems.items():
         frequencyFile.write('%s:%d\n' % (item, count))  # name : frequency 
    frequencyFile.close() # close new file 
# print unique grocery items 
def printGroceryTracker():
    print("\n  ITEM      QUANTITY PURCHASED")
    print("---------------------------------\n")
    for item, count in uniqueItems.items():
        print(item, count)
#locate item in dictionary and print frequency of item
def searchItem(name):
    if name in uniqueItems:
        return uniqueItems[name] # made to return count value of product as string 
    else:
        return 0
 

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v