// Joann Carter 
#include <Python.h>
#include <iostream>
#include <fstream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <typeinfo>
#include <stdlib.h> 
using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}


int main()
{
	int frequencyValue; //  item amount 
	int  menuInput = 0; // menu input 
	string userItem;  //user item passed as paramater from menu option 2
	bool itemFound = false; // used to validate user item has been found in grocery list 
	string item; // name of item 
	int count = 0; // amount of item
	ifstream frequencyFile; // read file created by python 
	string frequencyData; // to store read info 
	

// display menu until user enters 4
	while (menuInput != 4) {
// menu 
		cout << "\n1: List all items purchased" << endl;
		cout << "2: Find specific item inventory" << endl;
		cout << "3: Histogram" << endl;
		cout << "4: EXIT\n" << endl;
		cin >> menuInput;
// validate user input 
		switch (menuInput) {
// option 1 on menu --print all inventory 
		case 1:
			CallProcedure("printGroceryTracker");  // call printGroceryTracker() from PythonCode
			break;
// option 2 on menu --frequency of one item 
		case 2:
			cout << "SEARCH FOR:  ";		// prompt for item to search for
			
			while (!itemFound) { // validate user item is in list
				cin >> userItem;
				userItem[0] = toupper(userItem[0]);  // uppercase first letter of user search to match format on grocery list file 
			
				count = callIntFunc("searchItem", userItem); // search by name

				if (count > 0) {   // search for item 
					
					cout << "\n" << userItem << " : " << count << endl;
					itemFound = true;   // switch boolean to tru when item has been found
					break;
				}
				
				cin.clear();  // clears error flags
				cin.ignore(1000, '\n'); // skips up to 1000  characters to next newline 

				cout << "\nNONE FOUND! \nEnter a different item..." << endl; // prompts for another item
				
			}
			
			break;
// option 3 on menu --display histogram
		case 3:
			CallProcedure("createFrequencyFile"); // create new file with python 
			frequencyFile.open("frequency.dat");  // open file created in python 
			
			while (frequencyFile) {  // read file until the last line 
				getline(frequencyFile, frequencyData, '\n');
		
				int pos = frequencyData.find(":");  // locate location of semi colon 
			
				
				string sub = frequencyData.substr(pos + 1, frequencyData.length()); // Copy substring of quantity
				frequencyData = frequencyData.substr(0, pos + 1 );					// leave out the value on end 
				cout << frequencyData;												// print name of item
					
				while (sub.size() != 0) {					 // read each char digit
						int symbol = 0;						 // loop iterator
						frequencyValue = sub.back() - '0';   // convert char digit to int
						if (frequencyValue == 0) {			 // if digit is 0, print nine lines
							cout << "|||||||||" ;
						}

						while (symbol < frequencyValue) {  // print one line for each value up to 9
							cout << '|';
							symbol += 1;
						}
						sub.pop_back();					  // remove last char of substring
			
					}

				cout << endl;   // print out each line for histogrm 
			}
		
			frequencyFile.close();  // close file 
			break;
// option 4 on menu
		case 4:
			break;
// invalid option 
		default:
			break;
		}
	}
	return 0;
}